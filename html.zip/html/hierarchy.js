var hierarchy =
[
    [ "MarketPlaceProject.Customer", "class_market_place_project_1_1_customer.html", null ],
    [ "EventArgs", null, [
      [ "MarketPlaceProject.CartEventArgs", "class_market_place_project_1_1_cart_event_args.html", null ]
    ] ],
    [ "ICloneable", null, [
      [ "MarketPlaceProject.Goods", "class_market_place_project_1_1_goods.html", null ]
    ] ],
    [ "IEnumerable", null, [
      [ "MarketPlaceProject.GoodsCollection< T >", "class_market_place_project_1_1_goods_collection-1-g.html", null ]
    ] ],
    [ "MarketPlaceProject.ISerializableEntity", "interface_market_place_project_1_1_i_serializable_entity.html", [
      [ "MarketPlaceProject.Goods", "class_market_place_project_1_1_goods.html", null ]
    ] ],
    [ "MarketPlaceProject.Order", "class_market_place_project_1_1_order.html", null ],
    [ "MarketPlaceProject.ProductBase", "class_market_place_project_1_1_product_base.html", [
      [ "MarketPlaceProject.Goods", "class_market_place_project_1_1_goods.html", null ]
    ] ],
    [ "MarketPlaceProject.Program", "class_market_place_project_1_1_program.html", null ],
    [ "MarketPlaceProject.ShopManager", "class_market_place_project_1_1_shop_manager.html", null ],
    [ "MarketPlaceProject.ShoppingCart", "class_market_place_project_1_1_shopping_cart.html", null ]
];