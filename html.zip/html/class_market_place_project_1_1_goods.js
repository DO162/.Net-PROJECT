var class_market_place_project_1_1_goods =
[
    [ "Clone", "class_market_place_project_1_1_goods.html#af7f90e4716f385f8c5126640cee0da1f", null ],
    [ "Equals", "class_market_place_project_1_1_goods.html#ae7f39a3f6ac0957cb0e6bc35c088dd27", null ],
    [ "GetDescription", "class_market_place_project_1_1_goods.html#a650bb003d33ec79cf9fe663ef68f147b", null ],
    [ "GetHashCode", "class_market_place_project_1_1_goods.html#a39bad9e861dee74cd8463403dd928f3b", null ],
    [ "Serialize", "class_market_place_project_1_1_goods.html#ad98d4a564764ad594762d54fde62c0d9", null ],
    [ "ToString", "class_market_place_project_1_1_goods.html#ab18facea5cde32aa92f91690603c9d74", null ],
    [ "Quantity", "class_market_place_project_1_1_goods.html#a9b1a340a9aa9ffe15055b1f76b861be0", null ]
];