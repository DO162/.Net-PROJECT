var class_market_place_project_1_1_order =
[
    [ "Order", "class_market_place_project_1_1_order.html#aa2c08c540aac242220cb32d1873d7f0a", null ],
    [ "ToString", "class_market_place_project_1_1_order.html#ae20e5e217220be78d46d4632b1e7aff4", null ],
    [ "Date", "class_market_place_project_1_1_order.html#aa0b1b30f13fdee5784ced30df2dd514a", null ],
    [ "Id", "class_market_place_project_1_1_order.html#ad4ee965dde9c0e0d13e3d5dd8905cc61", null ],
    [ "Items", "class_market_place_project_1_1_order.html#af0b4fee5da4eea46a4fd3b0e414dcaac", null ],
    [ "Total", "class_market_place_project_1_1_order.html#a2ec73c5f0a5c4b7722cd8c714a70dcf0", null ]
];