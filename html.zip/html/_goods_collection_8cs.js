var _goods_collection_8cs =
[
    [ "MarketPlaceProject.GoodsCollection&lt; T &gt;", "class_market_place_project_1_1_goods_collection-1-g.html", "class_market_place_project_1_1_goods_collection-1-g" ]
];