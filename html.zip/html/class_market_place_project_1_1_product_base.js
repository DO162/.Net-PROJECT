var class_market_place_project_1_1_product_base =
[
    [ "ProductBase", "class_market_place_project_1_1_product_base.html#a24853130a0498faca7f294611887404c", null ],
    [ "GetDescription", "class_market_place_project_1_1_product_base.html#ad4972a026285c6b3c08df9efc3407102", null ],
    [ "Category", "class_market_place_project_1_1_product_base.html#a9e818b7f9451c38430d6f8501f1830e1", null ],
    [ "Id", "class_market_place_project_1_1_product_base.html#a57e19dd73ad58b17ae0b70fd1984955f", null ],
    [ "Name", "class_market_place_project_1_1_product_base.html#a2ad561901f653aa78492b403553993e3", null ],
    [ "Price", "class_market_place_project_1_1_product_base.html#ad84d405aa8795f378c495f1cc80a76dc", null ]
];