var _shop_manager_8cs =
[
    [ "MarketPlaceProject.ShopManager", "class_market_place_project_1_1_shop_manager.html", "class_market_place_project_1_1_shop_manager" ]
];