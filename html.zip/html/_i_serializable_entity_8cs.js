var _i_serializable_entity_8cs =
[
    [ "MarketPlaceProject.ISerializableEntity", "interface_market_place_project_1_1_i_serializable_entity.html", "interface_market_place_project_1_1_i_serializable_entity" ]
];