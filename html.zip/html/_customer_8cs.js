var _customer_8cs =
[
    [ "MarketPlaceProject.Customer", "class_market_place_project_1_1_customer.html", "class_market_place_project_1_1_customer" ]
];