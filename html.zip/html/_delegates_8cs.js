var _delegates_8cs =
[
    [ "MarketPlaceProject.CartEventArgs", "class_market_place_project_1_1_cart_event_args.html", "class_market_place_project_1_1_cart_event_args" ],
    [ "MarketPlaceProject.CartEventHandler", "namespace_market_place_project.html#a5ea584274ee1d106381f58ea276e19da", null ],
    [ "MarketPlaceProject.StockEventHandler", "namespace_market_place_project.html#ae6c806aa53961b9c9c42b2b36fe9da75", null ]
];