var files_dup =
[
    [ "obj", "dir_43724e81dd40e09f32417973865cdd64.html", "dir_43724e81dd40e09f32417973865cdd64" ],
    [ "Customer.cs", "_customer_8cs.html", "_customer_8cs" ],
    [ "Delegates.cs", "_delegates_8cs.html", "_delegates_8cs" ],
    [ "FileManager.cs", "_file_manager_8cs.html", null ],
    [ "Goods.cs", "_goods_8cs.html", "_goods_8cs" ],
    [ "GoodsCollection.cs", "_goods_collection_8cs.html", "_goods_collection_8cs" ],
    [ "GoodsData.cs", "_goods_data_8cs.html", null ],
    [ "Interface.cs", "_interface_8cs.html", null ],
    [ "ISerializableEntity.cs", "_i_serializable_entity_8cs.html", "_i_serializable_entity_8cs" ],
    [ "MenuManager.cs", "_menu_manager_8cs.html", null ],
    [ "Order.cs", "_order_8cs.html", "_order_8cs" ],
    [ "ProductBase.cs", "_product_base_8cs.html", "_product_base_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "ShopManager.cs", "_shop_manager_8cs.html", "_shop_manager_8cs" ],
    [ "ShoppingCart.cs", "_shopping_cart_8cs.html", "_shopping_cart_8cs" ]
];