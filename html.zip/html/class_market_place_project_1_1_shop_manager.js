var class_market_place_project_1_1_shop_manager =
[
    [ "CheckStock", "class_market_place_project_1_1_shop_manager.html#ace9ea701af7df0c78d4aa85914e50559", null ],
    [ "FilterByPrice", "class_market_place_project_1_1_shop_manager.html#a4350f1b18983d2dde22a2b27290c3602", null ],
    [ "Search", "class_market_place_project_1_1_shop_manager.html#a881c1dc7c9b0da0b49822a2af4845710", null ],
    [ "Goods", "class_market_place_project_1_1_shop_manager.html#af28bf8318c71398887982f55647564ca", null ],
    [ "LowStockAlert", "class_market_place_project_1_1_shop_manager.html#af980fd148583ffcbba19435ab6c8614d", null ]
];