var interface_market_place_project_1_1_i_serializable_entity =
[
    [ "Serialize", "interface_market_place_project_1_1_i_serializable_entity.html#a722e371e8d8b25dcfcc49e864aef8d30", null ]
];