var searchData=
[
  ['delegates_2ecs_0',['Delegates.cs',['../_delegates_8cs.html',1,'']]]
];
