var searchData=
[
  ['goods_0',['Goods',['../class_market_place_project_1_1_shop_manager.html#af28bf8318c71398887982f55647564ca',1,'MarketPlaceProject::ShopManager']]]
];
