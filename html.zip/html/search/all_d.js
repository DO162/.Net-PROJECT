var searchData=
[
  ['quantity_0',['Quantity',['../class_market_place_project_1_1_goods.html#a9b1a340a9aa9ffe15055b1f76b861be0',1,'MarketPlaceProject::Goods']]]
];
