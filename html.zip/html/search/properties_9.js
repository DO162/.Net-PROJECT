var searchData=
[
  ['phone_0',['Phone',['../class_market_place_project_1_1_customer.html#ac36ec1463cdde36f27d94ad7472e9f09',1,'MarketPlaceProject::Customer']]],
  ['price_1',['Price',['../class_market_place_project_1_1_product_base.html#ad84d405aa8795f378c495f1cc80a76dc',1,'MarketPlaceProject::ProductBase']]]
];
