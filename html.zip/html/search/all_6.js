var searchData=
[
  ['getdescription_0',['GetDescription',['../class_market_place_project_1_1_goods.html#a650bb003d33ec79cf9fe663ef68f147b',1,'MarketPlaceProject.Goods.GetDescription()'],['../class_market_place_project_1_1_product_base.html#ad4972a026285c6b3c08df9efc3407102',1,'MarketPlaceProject.ProductBase.GetDescription()']]],
  ['getenumerator_1',['GetEnumerator',['../class_market_place_project_1_1_goods_collection-1-g.html#acb4547c49763aebbed8c8de1217ea3fb',1,'MarketPlaceProject::GoodsCollection-1-g']]],
  ['gethashcode_2',['GetHashCode',['../class_market_place_project_1_1_goods.html#a39bad9e861dee74cd8463403dd928f3b',1,'MarketPlaceProject::Goods']]],
  ['goods_3',['Goods',['../class_market_place_project_1_1_goods.html',1,'MarketPlaceProject.Goods'],['../class_market_place_project_1_1_shop_manager.html#af28bf8318c71398887982f55647564ca',1,'MarketPlaceProject.ShopManager.Goods']]],
  ['goods_2ecs_4',['Goods.cs',['../_goods_8cs.html',1,'']]],
  ['goodscollection_2d1_2dg_5',['GoodsCollection-1-g',['../class_market_place_project_1_1_goods_collection-1-g.html',1,'MarketPlaceProject']]],
  ['goodscollection_2ecs_6',['GoodsCollection.cs',['../_goods_collection_8cs.html',1,'']]],
  ['goodsdata_2ecs_7',['GoodsData.cs',['../_goods_data_8cs.html',1,'']]]
];
