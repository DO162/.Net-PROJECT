var searchData=
[
  ['name_0',['Name',['../class_market_place_project_1_1_customer.html#a415e9b80810111d32fd36558635c3d53',1,'MarketPlaceProject.Customer.Name'],['../class_market_place_project_1_1_product_base.html#a2ad561901f653aa78492b403553993e3',1,'MarketPlaceProject.ProductBase.Name']]]
];
