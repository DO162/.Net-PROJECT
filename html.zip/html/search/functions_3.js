var searchData=
[
  ['filterbyprice_0',['FilterByPrice',['../class_market_place_project_1_1_shop_manager.html#a4350f1b18983d2dde22a2b27290c3602',1,'MarketPlaceProject::ShopManager']]]
];
