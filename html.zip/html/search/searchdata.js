var indexSectionsWithContent =
{
  0: ".acdefgilmnopqstw",
  1: "cgiops",
  2: "m",
  3: ".cdfgimops",
  4: "acefgopstw",
  5: "acdegimnopqt",
  6: "cl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "properties",
  6: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Properties",
  6: "Events"
};

