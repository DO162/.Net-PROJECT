var searchData=
[
  ['c_23_20_2d_20project_2eassemblyinfo_2ecs_0',['C# - PROJECT.AssemblyInfo.cs',['../_c_0g_01-_01_p_r_o_j_e_c_t_8_assembly_info_8cs.html',1,'']]],
  ['c_23_20_2d_20project_2eglobalusings_2eg_2ecs_1',['C# - PROJECT.GlobalUsings.g.cs',['../_c_0g_01-_01_p_r_o_j_e_c_t_8_global_usings_8g_8cs.html',1,'']]],
  ['customer_2ecs_2',['Customer.cs',['../_customer_8cs.html',1,'']]]
];
