var searchData=
[
  ['filemanager_2ecs_0',['FileManager.cs',['../_file_manager_8cs.html',1,'']]],
  ['filterbyprice_1',['FilterByPrice',['../class_market_place_project_1_1_shop_manager.html#a4350f1b18983d2dde22a2b27290c3602',1,'MarketPlaceProject::ShopManager']]]
];
