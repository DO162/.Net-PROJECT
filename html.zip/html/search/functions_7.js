var searchData=
[
  ['search_0',['Search',['../class_market_place_project_1_1_shop_manager.html#a881c1dc7c9b0da0b49822a2af4845710',1,'MarketPlaceProject::ShopManager']]],
  ['serialize_1',['Serialize',['../class_market_place_project_1_1_goods.html#ad98d4a564764ad594762d54fde62c0d9',1,'MarketPlaceProject.Goods.Serialize()'],['../interface_market_place_project_1_1_i_serializable_entity.html#a722e371e8d8b25dcfcc49e864aef8d30',1,'MarketPlaceProject.ISerializableEntity.Serialize()']]],
  ['stockeventhandler_2',['StockEventHandler',['../namespace_market_place_project.html#ae6c806aa53961b9c9c42b2b36fe9da75',1,'MarketPlaceProject']]]
];
