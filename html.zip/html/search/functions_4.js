var searchData=
[
  ['getdescription_0',['GetDescription',['../class_market_place_project_1_1_goods.html#a650bb003d33ec79cf9fe663ef68f147b',1,'MarketPlaceProject.Goods.GetDescription()'],['../class_market_place_project_1_1_product_base.html#ad4972a026285c6b3c08df9efc3407102',1,'MarketPlaceProject.ProductBase.GetDescription()']]],
  ['getenumerator_1',['GetEnumerator',['../class_market_place_project_1_1_goods_collection-1-g.html#acb4547c49763aebbed8c8de1217ea3fb',1,'MarketPlaceProject::GoodsCollection-1-g']]],
  ['gethashcode_2',['GetHashCode',['../class_market_place_project_1_1_goods.html#a39bad9e861dee74cd8463403dd928f3b',1,'MarketPlaceProject::Goods']]]
];
