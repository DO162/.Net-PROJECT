var searchData=
[
  ['tostring_0',['ToString',['../class_market_place_project_1_1_goods.html#ab18facea5cde32aa92f91690603c9d74',1,'MarketPlaceProject.Goods.ToString()'],['../class_market_place_project_1_1_order.html#ae20e5e217220be78d46d4632b1e7aff4',1,'MarketPlaceProject.Order.ToString()']]]
];
