var searchData=
[
  ['id_0',['Id',['../class_market_place_project_1_1_order.html#ad4ee965dde9c0e0d13e3d5dd8905cc61',1,'MarketPlaceProject.Order.Id'],['../class_market_place_project_1_1_product_base.html#a57e19dd73ad58b17ae0b70fd1984955f',1,'MarketPlaceProject.ProductBase.Id']]],
  ['instance_1',['Instance',['../class_market_place_project_1_1_customer.html#a8f7c12f5bd304e0eacff497e973da8c5',1,'MarketPlaceProject.Customer.Instance'],['../class_market_place_project_1_1_shop_manager.html#a9e64c3b2beccbc66fff1b70e289b0d8a',1,'MarketPlaceProject.ShopManager.Instance']]],
  ['interface_2ecs_2',['Interface.cs',['../_interface_8cs.html',1,'']]],
  ['iserializableentity_3',['ISerializableEntity',['../interface_market_place_project_1_1_i_serializable_entity.html',1,'MarketPlaceProject']]],
  ['iserializableentity_2ecs_4',['ISerializableEntity.cs',['../_i_serializable_entity_8cs.html',1,'']]],
  ['items_5',['Items',['../class_market_place_project_1_1_order.html#af0b4fee5da4eea46a4fd3b0e414dcaac',1,'MarketPlaceProject.Order.Items'],['../class_market_place_project_1_1_shopping_cart.html#af029bb4fe261f5488330e6b982b7f3de',1,'MarketPlaceProject.ShoppingCart.Items']]]
];
