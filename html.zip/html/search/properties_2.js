var searchData=
[
  ['date_0',['Date',['../class_market_place_project_1_1_order.html#aa0b1b30f13fdee5784ced30df2dd514a',1,'MarketPlaceProject::Order']]]
];
