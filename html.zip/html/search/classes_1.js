var searchData=
[
  ['goods_0',['Goods',['../class_market_place_project_1_1_goods.html',1,'MarketPlaceProject']]],
  ['goodscollection_2d1_2dg_1',['GoodsCollection-1-g',['../class_market_place_project_1_1_goods_collection-1-g.html',1,'MarketPlaceProject']]]
];
