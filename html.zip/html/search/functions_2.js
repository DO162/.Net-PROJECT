var searchData=
[
  ['equals_0',['Equals',['../class_market_place_project_1_1_goods.html#ae7f39a3f6ac0957cb0e6bc35c088dd27',1,'MarketPlaceProject::Goods']]]
];
