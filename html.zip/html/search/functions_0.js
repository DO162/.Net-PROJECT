var searchData=
[
  ['add_0',['Add',['../class_market_place_project_1_1_goods_collection-1-g.html#aa2917ed9a6bdfc372864c58617a33110',1,'MarketPlaceProject::GoodsCollection-1-g']]],
  ['additem_1',['AddItem',['../class_market_place_project_1_1_shopping_cart.html#aa114552bc33c2f6e7bdcd6acefb720d3',1,'MarketPlaceProject::ShoppingCart']]],
  ['addrange_2',['AddRange',['../class_market_place_project_1_1_goods_collection-1-g.html#ac82e99b7c449cc0b17c4d5458787c460',1,'MarketPlaceProject::GoodsCollection-1-g']]]
];
