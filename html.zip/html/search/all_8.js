var searchData=
[
  ['lowstockalert_0',['LowStockAlert',['../class_market_place_project_1_1_shop_manager.html#af980fd148583ffcbba19435ab6c8614d',1,'MarketPlaceProject::ShopManager']]]
];
