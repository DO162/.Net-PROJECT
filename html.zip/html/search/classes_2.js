var searchData=
[
  ['iserializableentity_0',['ISerializableEntity',['../interface_market_place_project_1_1_i_serializable_entity.html',1,'MarketPlaceProject']]]
];
