var searchData=
[
  ['message_0',['Message',['../class_market_place_project_1_1_cart_event_args.html#a375e981d3bee1eff80df5ec81db8d46a',1,'MarketPlaceProject::CartEventArgs']]]
];
