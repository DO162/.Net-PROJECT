var searchData=
[
  ['orders_0',['Orders',['../class_market_place_project_1_1_customer.html#a2c4334e0a9a5b5dfea90cbb6b0896a3f',1,'MarketPlaceProject::Customer']]]
];
