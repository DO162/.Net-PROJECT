var searchData=
[
  ['shopmanager_0',['ShopManager',['../class_market_place_project_1_1_shop_manager.html',1,'MarketPlaceProject']]],
  ['shoppingcart_1',['ShoppingCart',['../class_market_place_project_1_1_shopping_cart.html',1,'MarketPlaceProject']]]
];
