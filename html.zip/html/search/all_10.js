var searchData=
[
  ['where_0',['Where',['../class_market_place_project_1_1_goods_collection-1-g.html#a05565f70060abfb55a8452b85ccff168',1,'MarketPlaceProject::GoodsCollection-1-g']]]
];
