var searchData=
[
  ['this_5bint_20id_5d_0',['this[int id]',['../class_market_place_project_1_1_goods_collection-1-g.html#a2cacae500d3b4ec9f61ad465074703df',1,'MarketPlaceProject::GoodsCollection-1-g']]],
  ['this_5bstring_20name_5d_1',['this[string name]',['../class_market_place_project_1_1_goods_collection-1-g.html#ad0863c48e462fd28f29a0dae6b8f14c2',1,'MarketPlaceProject::GoodsCollection-1-g']]],
  ['total_2',['Total',['../class_market_place_project_1_1_order.html#a2ec73c5f0a5c4b7722cd8c714a70dcf0',1,'MarketPlaceProject::Order']]],
  ['totalprice_3',['TotalPrice',['../class_market_place_project_1_1_shopping_cart.html#aecafc29fd71c93e92103c4b423a5f77b',1,'MarketPlaceProject::ShoppingCart']]],
  ['totalvalue_4',['TotalValue',['../class_market_place_project_1_1_goods_collection-1-g.html#ad3db91a899a3d901fc042faeaa9b07c0',1,'MarketPlaceProject::GoodsCollection-1-g']]]
];
