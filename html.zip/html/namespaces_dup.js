var namespaces_dup =
[
    [ "MarketPlaceProject", "namespace_market_place_project.html", "namespace_market_place_project" ]
];