var class_market_place_project_1_1_goods_collection_1_g =
[
    [ "Add", "class_market_place_project_1_1_goods_collection-1-g.html#aa2917ed9a6bdfc372864c58617a33110", null ],
    [ "AddRange", "class_market_place_project_1_1_goods_collection-1-g.html#ac82e99b7c449cc0b17c4d5458787c460", null ],
    [ "GetEnumerator", "class_market_place_project_1_1_goods_collection-1-g.html#acb4547c49763aebbed8c8de1217ea3fb", null ],
    [ "OrderBy< TKey >", "class_market_place_project_1_1_goods_collection-1-g.html#afde5dd20735261f93845fe7bfc8086c4", null ],
    [ "Where", "class_market_place_project_1_1_goods_collection-1-g.html#a05565f70060abfb55a8452b85ccff168", null ],
    [ "Count", "class_market_place_project_1_1_goods_collection-1-g.html#ab964d9992ff29a441851bb2435b42066", null ],
    [ "this[int id]", "class_market_place_project_1_1_goods_collection-1-g.html#a2cacae500d3b4ec9f61ad465074703df", null ],
    [ "this[string name]", "class_market_place_project_1_1_goods_collection-1-g.html#ad0863c48e462fd28f29a0dae6b8f14c2", null ],
    [ "TotalValue", "class_market_place_project_1_1_goods_collection-1-g.html#ad3db91a899a3d901fc042faeaa9b07c0", null ]
];