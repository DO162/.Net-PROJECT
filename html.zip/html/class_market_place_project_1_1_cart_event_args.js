var class_market_place_project_1_1_cart_event_args =
[
    [ "CartEventArgs", "class_market_place_project_1_1_cart_event_args.html#a33b7ec56d6ae44caf2dbc1e086c4311d", null ],
    [ "Message", "class_market_place_project_1_1_cart_event_args.html#a375e981d3bee1eff80df5ec81db8d46a", null ]
];