var namespace_market_place_project =
[
    [ "Customer", "class_market_place_project_1_1_customer.html", "class_market_place_project_1_1_customer" ],
    [ "CartEventArgs", "class_market_place_project_1_1_cart_event_args.html", "class_market_place_project_1_1_cart_event_args" ],
    [ "Goods", "class_market_place_project_1_1_goods.html", "class_market_place_project_1_1_goods" ],
    [ "GoodsCollection&lt; T &gt;", "class_market_place_project_1_1_goods_collection-1-g.html", "class_market_place_project_1_1_goods_collection-1-g" ],
    [ "ISerializableEntity", "interface_market_place_project_1_1_i_serializable_entity.html", "interface_market_place_project_1_1_i_serializable_entity" ],
    [ "Order", "class_market_place_project_1_1_order.html", "class_market_place_project_1_1_order" ],
    [ "ProductBase", "class_market_place_project_1_1_product_base.html", "class_market_place_project_1_1_product_base" ],
    [ "Program", "class_market_place_project_1_1_program.html", null ],
    [ "ShopManager", "class_market_place_project_1_1_shop_manager.html", "class_market_place_project_1_1_shop_manager" ],
    [ "ShoppingCart", "class_market_place_project_1_1_shopping_cart.html", "class_market_place_project_1_1_shopping_cart" ],
    [ "CartEventHandler", "namespace_market_place_project.html#a5ea584274ee1d106381f58ea276e19da", null ],
    [ "StockEventHandler", "namespace_market_place_project.html#ae6c806aa53961b9c9c42b2b36fe9da75", null ]
];