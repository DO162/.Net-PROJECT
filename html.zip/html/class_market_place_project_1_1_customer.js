var class_market_place_project_1_1_customer =
[
    [ "Address", "class_market_place_project_1_1_customer.html#a0c0e02d71a4c0fbdbc1f86b45ba762bc", null ],
    [ "Cart", "class_market_place_project_1_1_customer.html#af2cd9645e4e1acc5e930d14685403c6d", null ],
    [ "Email", "class_market_place_project_1_1_customer.html#a45397c970f39139f121245537de9c2a8", null ],
    [ "Name", "class_market_place_project_1_1_customer.html#a415e9b80810111d32fd36558635c3d53", null ],
    [ "Orders", "class_market_place_project_1_1_customer.html#a2c4334e0a9a5b5dfea90cbb6b0896a3f", null ],
    [ "Phone", "class_market_place_project_1_1_customer.html#ac36ec1463cdde36f27d94ad7472e9f09", null ]
];